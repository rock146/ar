# AR Orb Pop — Multiplayer

## What's here
- `server.js` + `package.json` — a small Node.js WebSocket relay. Players join a "room code" and get synced orb placements, pops, and scores.
- `ar-orb-game-multiplayer.html` — the game client. Shows a lobby to enter the server address + room code, then launches the AR session.

## 1. Deploy the server
This needs to run somewhere reachable over the internet (a phone in AR can't connect to `localhost` on your laptop). Easiest free options:

- **Render.com** — new Web Service, connect a repo (or upload these files), build command `npm install`, start command `npm start`. It gives you a `https://your-app.onrender.com` URL — use `wss://your-app.onrender.com` in the game's lobby.
- **Railway.app** or **Glitch.com** — similar one-click Node deploy flow.
- **Fly.io** — `fly launch` in this folder, then `fly deploy`.

Any of these gives you a public `wss://...` address once deployed.

## 2. Host the game file
The HTML file itself just needs static HTTPS hosting (WebXR requires a secure context):
- Netlify (drag-and-drop the `.html` file), Vercel, or GitHub Pages all work.

## 3. Play
1. Open the hosted game URL on an Android phone in Chrome.
2. In the lobby screen, enter your `wss://...` server address and a room code (e.g. `lobby1`).
3. Tap Connect, then tap "Start AR" and grant camera permission.
4. Have a second phone do the same with the *same* room code — you're now in the same session, sharing score.

## Known limitation: spatial alignment
Each phone's AR session starts its own coordinate system the moment tracking begins — there's no built-in way for two phones to agree on "this exact spot in the room." So right now, an orb another player places will appear in *your* space at the same relative coordinates they used, not necessarily the same physical spot you'd see if you both looked at the same table.

What's synced correctly: orb events, pops, and score — a real shared multiplayer game loop.
What's not yet: physical co-location of objects.

To fix that, the next step would be **ARCore Cloud Anchors** (Android-only, lets devices agree on a shared origin by both scanning the same real surface) or a **printed marker** both phones scan at the start to align coordinate systems. Happy to add either if you want true shared-space placement.
